/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obsproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author ROY
 */
public class LOGINController implements Initializable {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String DB_USER = "ROY001";
    private static final String DB_PASSWORD = "1234";

    @FXML
    private TextField adminID;
    @FXML
    private TextField adminPASS;

    @FXML
    private Label ADMINLABLE;

    public static String name;
    public static String mail;
    @FXML
    public TextField usertf;
    public TextField passwordtf;
    public Label txtlable;

    @FXML
    public void loginbutton(ActionEvent event) throws IOException, SQLException {
        Connection dbConnection = null;
        Statement statement = null;
        dbConnect db = new dbConnect();
        Connection Conn = db.getConn();

        System.out.println("CONNECTION ESTABLISHED");
        String A = usertf.getText();
        String B = passwordtf.getText();
        LOGINController.mail = A;

        int log = 1;
        try {

            String querySQL = "select EMAIL_ID,CLNT_PASSWORD,CLNT_NAME from REGISTRATION WHERE  EMAIL_ID = '" + A + "' and CLNT_PASSWORD = '" + B + "' ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                if (rs.getString(1).equals(A) && rs.getString(2).equals(B)) {
                    log = 0;
                    String x = rs.getString(3);
                    LOGINController.name = x;
                } else {
                    log = 1;
                }
            }
            if (log == 0) {
                Parent tableViewParent = FXMLLoader.load(getClass().getResource("HOMENEW.fxml"));
                Scene tableViewScene = new Scene(tableViewParent);

                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

                window.setScene(tableViewScene);
                window.show();
            } else if (log == 1) {
                txtlable.setText("LOGIN FAILED");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }

    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void gobutton(ActionEvent event) throws IOException {
        Connection dbConnection = null;
        Statement statement = null;
        dbConnect db = new dbConnect();
        Connection Conn = db.getConn();

        System.out.println("CONNECTION ESTABLISHED");
        String A = adminID.getText();
        String B = adminPASS.getText();

        int log = 1;
        try {

            String querySQL = "select ADMIN_ID,ADMIN_PASSWORD from ADMIN WHERE  ADMIN_ID = 'ROY' and ADMIN_PASSWORD  = '04322' ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                if (rs.getString(1).equals(A) && rs.getString(2).equals(B)) {
                    log = 0;

                } else {
                    log = 1;
                }
            }
            if (log == 0) {
                Parent tableViewParent = FXMLLoader.load(getClass().getResource("ADMIN.fxml"));
                Scene tableViewScene = new Scene(tableViewParent);

                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

                window.setScene(tableViewScene);
                window.show();
            } else if (log == 1) {
                ADMINLABLE.setText("FALSE ADMIN");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @FXML
    private void RegisterButtonActionNEW(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("REGISTRATION.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

}
