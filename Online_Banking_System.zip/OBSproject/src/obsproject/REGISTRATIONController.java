//Here’s an example to show you how to insert a record into table via JDBC statement. To issue a insert statement, calls the Statement.executeUpdate() method like this :
//Statement statement = dbConnection.createStatement();
// execute the insert SQL stetement
//statement.executeUpdate(insertTableSQL);
//Full example…
package obsproject;

import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class REGISTRATIONController implements Initializable {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String DB_USER = "ROY001";
    private static final String DB_PASSWORD = "1234";

    @FXML
    public TextField textFiled1;
    public TextField textFiled2;
    public CheckBox cb1;
    public CheckBox cb2;
    public DatePicker dp;
    public PasswordField passwordField;
    public CheckBox cb3;
    public CheckBox cb4;
    public Label tf1;
    public Label tf2;
    public Label tf5;
    public Label tf3;
    public Label tf4;
    public Label tf6;
    public Label textLable;

    @FXML
    public void submitbutton(ActionEvent event) throws SQLException, IOException {
        Connection dbConnection = null;
        Statement statement = null;
        String name = textFiled1.getText();
        String email = textFiled2.getText();
        String date = dp.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        String gender;
        if (cb2.isSelected()) {
            gender = cb2.getText();
        } else {
            gender = cb1.getText();
        }
        String pass = passwordField.getText();
        String account;
        if (cb3.isSelected()) {
            account = cb3.getText();
        } else {
            account = cb4.getText();
        }
        System.out.println("CONNECTION ESTABLISHED");

        String querySQL = "INSERT INTO REGISTRATION"
                + "(CLNT_GENDER,CLNT_NAME,EMAIL_ID,DATE_OF_BIRTH,ACCOUNT_TYPE,CLNT_PASSWORD)"
                + "VALUES('" + gender + "' , '" + name + "' , '" + email + "', '" + date + "', '" + account + "' , '" + pass + "')";
        String querySQL2 = "INSERT INTO CLNT_TRA_INFO"
                + "(CLNT_NAME,CLNT_ID)"
                + "VALUES('" + name + "' , '" + email + "')";

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(querySQL);
            statement.executeUpdate(querySQL);
            statement.executeUpdate(querySQL2);

            textLable.setText("RESGISTRATION SUCCESSFULLY");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            textLable.setText("RESGISTRATION FAILED");
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }

        }

    }

    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    }

    @FXML
    private void signinbutton(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
