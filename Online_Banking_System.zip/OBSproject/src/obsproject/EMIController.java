/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obsproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static obsproject.HOMENEWController.L;
import static obsproject.LOGINController.mail;
import static obsproject.LOGINController.name;

/**
 * FXML Controller class
 *
 * @author ROY
 */
public class EMIController implements Initializable {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String DB_USER = "ROY001";
    private static final String DB_PASSWORD = "1234";

    HOMENEWController obj = new HOMENEWController();
    public static Float i, j;
    public static Float k;
    public static String EM;
    public Label emilable1;
    public ChoiceBox<String> choicebox;
    public Button selectmonth;
    public Label emilable2;
    public Label emilable3;
    public TextField tf1;
    public TextField tf2;
    public TextField tf3;
    public TextField tf4;
    public TextField tf5;
    public TextField tf6;
    public TextField tf7;
    public TextField tf8;
    public TextField tf9;
    public TextField tf10;
    public TextField tf11;
    public TextField tf12;
    public Label emilablecon;
    public Label currentloan;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tf1.setText("N/A");
        tf2.setText("N/A");
        tf3.setText("N/A");
        tf4.setText("N/A");
        tf5.setText("N/A");
        tf6.setText("N/A");
        tf7.setText("N/A");
        tf8.setText("N/A");
        tf9.setText("N/A");
        tf10.setText("N/A");
        tf11.setText("N/A");
        tf12.setText("N/A");
        emilable1.setText(L + "taka loan ?");
        currentloan.setText(L);
        choicebox.getItems().addAll("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12");

    }

    @FXML
    public void selectmonth(ActionEvent event) {
        String month = choicebox.getValue();
        float MONTH1 = Float.parseFloat(month);
        i = MONTH1;
        float loanmoney = Float.parseFloat(L);
        j = loanmoney;
        float emi = loanmoney / MONTH1;
        k = emi;
        String EMI = Float.toString(emi);
        EM = EMI;

        emilable2.setText("You have to pay " + EMI + " taka per month , for " + L + " taka loan in " + month + " months");
    }

    @FXML
    public void YESbutton(ActionEvent event) {
        emilable3.setText("Thanks Sir, If you want you can pay the first month EMI");
        if (i == 1) {
            tf1.setText(EM);
            tf2.setText("N/A");
            tf3.setText("N/A");
            tf4.setText("N/A");
            tf5.setText("N/A");
            tf6.setText("N/A");
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 2) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText("N/A");
            tf4.setText("N/A");
            tf5.setText("N/A");
            tf6.setText("N/A");
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 3) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText("N/A");
            tf5.setText("N/A");
            tf6.setText("N/A");
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 4) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText("N/A");
            tf6.setText("N/A");
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 5) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText("N/A");
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 6) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText("N/A");
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 7) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText("N/A");
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 8) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText(EM);
            tf9.setText("N/A");
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 9) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText(EM);
            tf9.setText(EM);
            tf10.setText("N/A");
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 10) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText(EM);
            tf9.setText(EM);
            tf10.setText(EM);
            tf11.setText("N/A");
            tf12.setText("N/A");
        } else if (i == 11) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText(EM);
            tf9.setText(EM);
            tf10.setText(EM);
            tf11.setText(EM);
            tf12.setText("N/A");
        } else if (i == 12) {
            tf1.setText(EM);
            tf2.setText(EM);
            tf3.setText(EM);
            tf4.setText(EM);
            tf5.setText(EM);
            tf6.setText(EM);
            tf7.setText(EM);
            tf8.setText(EM);
            tf9.setText(EM);
            tf10.setText(EM);
            tf11.setText(EM);
            tf12.setText(EM);
        }

    }

    @FXML
    public void NObutton(ActionEvent event) {
        emilable3.setText("Select the month number again");
    }

    @FXML
    public void EMI1(ActionEvent event) {
        if (tf1.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);

            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sql1 = "UPDATE EMI SET FIRST_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf1.setText("PAID");
                emilablecon.setText("1st Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @FXML
    public void EMI2(ActionEvent event) {
        if (tf2.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);

            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sql1 = "UPDATE EMI SET SECOND_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf2.setText("PAID");
                emilablecon.setText("2nd Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }

    }

    @FXML
    public void EMI3(ActionEvent event) {
        if (tf3.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sql1 = "UPDATE EMI SET THIRD_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf3.setText("PAID");
                emilablecon.setText("3rd Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI4(ActionEvent event) {
        if (tf4.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sql1 = "UPDATE EMI SET FOURTH_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf4.setText("PAID");
                emilablecon.setText("4th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI7(ActionEvent event) {
        if (tf7.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET SEVEN_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf7.setText("PAID");
                emilablecon.setText("7th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }

    }

    @FXML
    public void EMI8(ActionEvent event) {
        if (tf8.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET EIGHT_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf8.setText("PAID");
                emilablecon.setText("8th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI9(ActionEvent event) {
        if (tf9.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET NINE_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf9.setText("PAID");
                emilablecon.setText("9th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI10(ActionEvent event) {
        if (tf10.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET TEN_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf10.setText("PAID");
                emilablecon.setText("10th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI5(ActionEvent event) {
        if (tf5.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET FIVE_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf5.setText("PAID");
                emilablecon.setText("5th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI6(ActionEvent event) {
        if (tf6.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET SIX_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf6.setText("PAID");
                emilablecon.setText("6th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI11(ActionEvent event) {
        if (tf11.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET ELEVEN_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf11.setText("PAID");
                emilablecon.setText("11th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    @FXML
    public void EMI12(ActionEvent event) {
        if (tf12.getText().equals(EM)) {
            Connection dbConnection = null;
            Statement statement = null;
            float newloan = j - k;
            if (newloan <= 0.0) {
                newloan = (float) 0.0;
                System.out.print(newloan);
            }
            j = newloan;
            String NEWLOAN = Float.toString(newloan);
            currentloan.setText(NEWLOAN);
            String sqlhome = "UPDATE CLNT_TRA_INFO SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            String sqlhome2 = "UPDATE EMI SET LOAN = '" + NEWLOAN + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

            String sql1 = "UPDATE EMI SET TWELVE_M = '" + EM + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                statement.executeUpdate(sql1);
                statement.executeUpdate(sqlhome);
                statement.executeUpdate(sqlhome2);
                tf12.setText("PAID");
                emilablecon.setText("12th Month's EMI PAID");
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else {
            emilablecon.setText("NO NEED");
        }
    }

    public static Connection getDBConnection() {
        Connection dbConnection = null;
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());
        }
        try {
            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }

    @FXML
    public void homebutton(ActionEvent event) throws IOException {

        Parent tableViewParent = FXMLLoader.load(getClass().getResource("HOMENEW.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

}
