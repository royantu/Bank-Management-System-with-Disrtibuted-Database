/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obsproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static obsproject.LOGINController.mail;
import static obsproject.LOGINController.name;
import java.util.Date;

/**
 * FXML Controller class
 *
 * @author ROY
 */
public class HOMENEWController implements Initializable {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String DB_USER = "ROY001";
    private static final String DB_PASSWORD = "1234";
    LOGINController obj = new LOGINController();
    public static String L;
    public static String dd;
    @FXML
    public Label txtlableNAME;
    public Label txtlableEMAIL;
    public Label txtlableCA;
    public Label txtlableLOAN;
    public Label txtlableWITHDRAW;
    public Label txtlableLOANREQ;
    public Label txtlableCASHOUT;
    public Label txtlableCASHIN;
    public Label txtlableINSAPPLY;
    public TextField depositetf;
    public TextField withdrawtf;
    public TextField loantf;
    public TextField insurancetf;
    public Label tfemi1;
    @FXML
    private Label depoline;
    @FXML
    private Label loanline;
    @FXML
    private Label withdrawline;
    @FXML
    private Label insuranceline;
    @FXML
    private Label dateid;
    @FXML
    private Label dateid1;
    @FXML
    private Label dateid2;
    @FXML
    private Label dateid3;
    @FXML
    private Label lastwithdrawdate;

    @FXML
    public void CASHIN(ActionEvent event) throws SQLException {
        String A = name;
        String B = mail;
        String money = depositetf.getText();
        int cashin = Integer.parseInt(money);
        Connection dbConnection = null;
        Statement statement = null;
        try {
            String querySQL = "SELECT CURRENT_AMOUNT FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String x = rs.getString(1);
                if (x.equals(null)) {

                    String CASHINSQL = "UPDATE CLNT_TRA_INFO SET CURRENT_AMOUNT = '" + money + "' WHERE CLNT_NAME = '" + A + "' AND CLNT_ID = '" + B + "' ";
                    try {
                        dbConnection = getDBConnection();
                        statement = dbConnection.createStatement();
                        System.out.println(CASHINSQL);
                        statement.executeUpdate(CASHINSQL);

                        depoline.setText("" + money + " TK CASH IN SUCCESSFULLY");
                        txtlableCA.setText(money + " taka");
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else {
                    int mainblc = Integer.parseInt(x);
                    cashin = cashin + mainblc;
                    String CA = Integer.toString(cashin);
                    String CASHINSQL = "UPDATE CLNT_TRA_INFO SET CURRENT_AMOUNT = '" + CA + "' WHERE CLNT_NAME = '" + A + "' AND CLNT_ID = '" + B + "' ";
                    try {
                        dbConnection = getDBConnection();
                        statement = dbConnection.createStatement();
                        System.out.println(CASHINSQL);
                        statement.executeUpdate(CASHINSQL);

                        depoline.setText("" + money + " TK CASH IN SUCCESSFULLY");
                        txtlableCA.setText(CA + " taka");
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @FXML
    public void CASHOUT(ActionEvent event) throws SQLException {
        Connection dbConnection = null;
        Statement statement = null;
        dbConnect db = new dbConnect();
        String withdraw = withdrawtf.getText();
        int cashout = Integer.parseInt(withdraw);
        try {
            String CASHOUTSQL = "SELECT CURRENT_AMOUNT FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            System.out.println(CASHOUTSQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(CASHOUTSQL);

            while (rs.next()) {
                String x = rs.getString(1);
                int mainblc = Integer.parseInt(x);
                if (mainblc > cashout) {
                    int current_amount = mainblc - cashout;
                    String CA = Integer.toString(current_amount);
                    String CASHOUTSQL1 = "UPDATE CLNT_TRA_INFO SET CURRENT_AMOUNT = '" + CA + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    String CASHOUTSQL2 = "UPDATE CLNT_TRA_INFO SET WITHDRAW = '" + withdraw + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    try {
                        dbConnection = getDBConnection();
                        statement = dbConnection.createStatement();
                        System.out.println(CASHOUTSQL);
                        statement.executeUpdate(CASHOUTSQL1);
                        statement.executeUpdate(CASHOUTSQL2);

                        withdrawline.setText("" + withdraw + " TK CASH OUT SUCCESSFULLY");
                        txtlableCA.setText(CA + " taka");
                        txtlableWITHDRAW.setText(withdraw + " taka");
                        Date date = new Date();
                        String d =date.toString();
                        dd=d;
                        lastwithdrawdate.setText("at "+dd);
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                } else {
                    withdrawline.setText("You have " + mainblc + " TK You cann't withdraw " + withdraw + " TK");
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void LOANREQ(ActionEvent event) throws SQLException {
        String loan = loantf.getText();
        HOMENEWController.L = loan;
        Connection dbConnection = null;
        Statement statement = null;
        float loan_get = Integer.parseInt(loan);

        try {

            String querySQL = "SELECT LOAN FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String Y = rs.getString(1);
                if (Y.equals(null)) {

                    String LOANSQL1 = "UPDATE CLNT_TRA_INFO SET LOAN = '" + loan + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    String LOANSQL3 = "UPDATE EMI SET LOAN = '" + loan + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    try {
                        dbConnection = getDBConnection();
                        statement = dbConnection.createStatement();
                        System.out.println(LOANSQL1);
                        statement.executeUpdate(LOANSQL1);
                        statement.executeUpdate(LOANSQL3);

                        loanline.setText("YOU GOT " + loan + " TK LOAN");
                        txtlableLOAN.setText(loan + " taka");
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else {
                    float mainblc = Float.parseFloat(Y);
                    loan_get = loan_get + mainblc;
                    String CA = Float.toString(loan_get);
                    HOMENEWController.L = CA;
                    String LOANSQL4 = "UPDATE EMI SET LOAN = '" + CA + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    String LOANSQL2 = "UPDATE CLNT_TRA_INFO SET LOAN = '" + CA + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
                    try {
                        dbConnection = getDBConnection();
                        statement = dbConnection.createStatement();
                        System.out.println(LOANSQL2);
                        statement.executeUpdate(LOANSQL2);
                        statement.executeUpdate(LOANSQL4);
                        loanline.setText("YOU GOT " + loan + " TK LOAN");
                        txtlableLOAN.setText(CA + " taka");
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @FXML
    public void INSAPPLY(ActionEvent event) throws SQLException {
        String ins = insurancetf.getText();
        Connection dbConnection = null;
        Statement statement = null;

        String INSURANCESQL = "UPDATE CLNT_TRA_INFO SET INSURANCE = '" + ins + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";
        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(INSURANCESQL);
            statement.executeUpdate(INSURANCESQL);

           insuranceline.setText("YOU GOT " + ins + " TK INSURANCE");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    public void SIGNOUT(ActionEvent event) throws IOException {

        Parent tableViewParent = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lastwithdrawdate.setText("NOT YET HAPPENED");
        Date date = new Date();

         String d =date.toString();
         dateid.setText(d);
         dateid1.setText(d);
         dateid2.setText(d);
         dateid3.setText(d);
        txtlableNAME.setText(name);
        txtlableEMAIL.setText(mail);
        Connection dbConnection = null;
        Statement statement = null;
        dbConnect db = new dbConnect();

        try {
            String querySQL = "SELECT CURRENT_AMOUNT FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String x = rs.getString(1);
                txtlableCA.setText(x + " taka");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        try {
            String querySQL1 = "SELECT LOAN FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs1 = statement.executeQuery(querySQL1);

            while (rs1.next()) {
                String x = rs1.getString(1);
                HOMENEWController.L = x;
                txtlableLOAN.setText(x + " taka");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        try {
            String querySQL1 = "SELECT WITHDRAW FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs1 = statement.executeQuery(querySQL1);

            while (rs1.next()) {
                String x = rs1.getString(1);
                txtlableWITHDRAW.setText(x + " taka");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        int log = 0;
        try {
            String querySQL = "SELECT CLNT_NAME,CLNT_ID FROM EMI WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                if (rs.getString(1) == null && rs.getString(2) == null) {
                    log = 1;

                } else if (rs.getString(1).equals(name) && rs.getString(2).equals(mail)) {
                    log = 0;

                }
            }
            if (log == 0) {
                tfemi1.setText("EMI ACTIVATED");
            } else if (log == 1) {
                tfemi1.setText("EMI DEACTIVATED");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // TODO
    @FXML
    public void EMIMANAGEMENT(ActionEvent event) throws IOException {
        Connection dbConnection = null;
        Statement statement = null;
        String LOANSQL5 = "UPDATE EMI SET LOAN = '" + L + "' WHERE CLNT_NAME = '" + name + "' AND CLNT_ID = '" + mail + "' ";

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            statement.executeUpdate(LOANSQL5);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("EMI.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

    @FXML
    public void EMIACTIVE(ActionEvent event) {
        Connection dbConnection = null;
        Statement statement = null;
        String querySQL2 = "INSERT INTO EMI"
                + "(CLNT_NAME,CLNT_ID)"
                + "VALUES('" + name + "' , '" + mail + "')";
        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            statement.executeUpdate(querySQL2);
            tfemi1.setText("EMI ACTIVATED");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static Connection getDBConnection() {
        Connection dbConnection = null;
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());
        }
        try {
            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }

}
