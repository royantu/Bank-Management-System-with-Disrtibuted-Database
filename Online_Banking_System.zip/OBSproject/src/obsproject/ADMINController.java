/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obsproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ROY
 */
public class ADMINController implements Initializable {

    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static final String DB_USER = "ROY001";
    private static final String DB_PASSWORD = "1234";
    public static String a, b, c, d, e;
    @FXML
    private TextField search_name;
    @FXML
    private TextField search_email;
    @FXML
    private TextField search_gender;
    @FXML
    private TextField search_date_of_birth;
    @FXML
    private TextField search_account_type;
    @FXML
    private TextField search_current_amount;
    @FXML
    private TextField search_loan;
    @FXML
    private TextField search_withdraw;
    @FXML
    private TextField search_insurance;
    @FXML
    private CheckBox checkbox_mail;
    @FXML
    private CheckBox checkbox_name;
    @FXML
    private TextField textfield_name_email;
    @FXML
    private TextField search_nameU;
    @FXML
    private TextField search_emailU;
    @FXML
    private TextField search_date_of_birthU;
    @FXML
    private TextField search_account_typeU;
    @FXML
    private CheckBox checkbox_mailU;
    @FXML
    private CheckBox checkbox_nameU;
    @FXML
    private TextField textfield_name_emailU;
    @FXML
    private TextField passwordU;
    @FXML
    private Label updatedlable;
    @FXML
    private Label namelable;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void searchbutton(ActionEvent event) {
        if (checkbox_mail.isSelected()) {
            String mail = textfield_name_email.getText();
            Connection dbConnection = null;
            Statement statement = null;
            dbConnect db = new dbConnect();

            try {
                String querySQL = "SELECT CLNT_NAME,EMAIL_ID,CLNT_GENDER,DATE_OF_BIRTH,ACCOUNT_TYPE FROM REGISTRATION WHERE EMAIL_ID = '" + mail + "'  ";
                System.out.println(querySQL);
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs = statement.executeQuery(querySQL);

                while (rs.next()) {
                    String W = rs.getString(1);
                    String X = rs.getString(2);
                    String Y = rs.getString(3);
                    String Z = rs.getString(4);
                    String A = rs.getString(5);
                    search_name.setText(W);
                    search_email.setText(X);
                    search_gender.setText(Y);
                    search_date_of_birth.setText(Z);
                    search_account_type.setText(A);

                }
                String querySQL1 = "SELECT CURRENT_AMOUNT,LOAN,WITHDRAW,INSURANCE FROM CLNT_TRA_INFO WHERE CLNT_ID = '" + mail + "'  ";
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs1 = statement.executeQuery(querySQL1);
                while (rs1.next()) {
                    String B = rs1.getString(1);
                    String C = rs1.getString(2);
                    String D = rs1.getString(3);
                    String E = rs1.getString(4);
                    search_current_amount.setText(B);
                    search_loan.setText(C);
                    search_withdraw.setText(D);
                    search_insurance.setText(E);
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else if (checkbox_name.isSelected()) {
            String name = textfield_name_email.getText();
            Connection dbConnection = null;
            Statement statement = null;
            dbConnect db = new dbConnect();

            try {
                String querySQL = "SELECT CLNT_NAME,EMAIL_ID,CLNT_GENDER,DATE_OF_BIRTH,ACCOUNT_TYPE FROM REGISTRATION WHERE CLNT_NAME = '" + name + "'  ";
                System.out.println(querySQL);
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs = statement.executeQuery(querySQL);

                while (rs.next()) {
                    String W = rs.getString(1);
                    String X = rs.getString(2);
                    String Y = rs.getString(3);
                    String Z = rs.getString(4);
                    String A = rs.getString(5);
                    search_name.setText(W);
                    search_email.setText(X);
                    search_gender.setText(Y);
                    search_date_of_birth.setText(Z);
                    search_account_type.setText(A);

                }
                String querySQL1 = "SELECT CURRENT_AMOUNT,LOAN,WITHDRAW,INSURANCE FROM CLNT_TRA_INFO WHERE CLNT_NAME = '" + name + "'  ";
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs1 = statement.executeQuery(querySQL1);
                while (rs1.next()) {
                    String B = rs1.getString(1);
                    String C = rs1.getString(2);
                    String D = rs1.getString(3);
                    String E = rs1.getString(4);
                    search_current_amount.setText(B);
                    search_loan.setText(C);
                    search_withdraw.setText(D);
                    search_insurance.setText(E);
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private static Connection getDBConnection() {
        Connection dbConnection = null;
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());
        }
        try {
            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }

    @FXML
    private void updatesearchbutton(ActionEvent event) {
        if (checkbox_mailU.isSelected()) {
            String mail = textfield_name_emailU.getText();
            Connection dbConnection = null;
            Statement statement = null;
            dbConnect db = new dbConnect();

            try {
                String querySQL = "SELECT CLNT_NAME,EMAIL_ID,CLNT_PASSWORD,DATE_OF_BIRTH,ACCOUNT_TYPE FROM REGISTRATION WHERE EMAIL_ID = '" + mail + "'  ";
                System.out.println(querySQL);
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs = statement.executeQuery(querySQL);

                while (rs.next()) {
                    a = rs.getString(1);
                    b = rs.getString(2);
                    c = rs.getString(3);
                    d = rs.getString(4);
                    e = rs.getString(5);

                    search_nameU.setText(a);
                    search_emailU.setText(b);
                    passwordU.setText(c);
                    search_date_of_birthU.setText(d);
                    search_account_typeU.setText(e);
                    namelable.setText("Don't Change the name");
                }

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        } else if (checkbox_nameU.isSelected()) {
            String name = textfield_name_emailU.getText();
            Connection dbConnection = null;
            Statement statement = null;
            dbConnect db = new dbConnect();

            try {
                String querySQL = "SELECT CLNT_NAME,EMAIL_ID,CLNT_PASSWORD,DATE_OF_BIRTH,ACCOUNT_TYPE FROM REGISTRATION WHERE CLNT_NAME = '" + name + "'  ";
                System.out.println(querySQL);
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                ResultSet rs = statement.executeQuery(querySQL);

                while (rs.next()) {
                    a = rs.getString(1);
                    b = rs.getString(2);
                    c = rs.getString(3);
                    d = rs.getString(4);
                    e = rs.getString(5);
                    search_nameU.setText(a);
                    search_emailU.setText(b);
                    passwordU.setText(c);
                    search_date_of_birthU.setText(d);
                    search_account_typeU.setText(e);
                    namelable.setText("Don't Change the name");

                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @FXML
    private void updatebutton(ActionEvent event) {
        Connection dbConnection = null;
        Statement statement = null;
        String A, B, C, D, E;
        A = search_nameU.getText();
        B = search_emailU.getText();
        C = passwordU.getText();
        D = search_date_of_birthU.getText();
        E = search_account_typeU.getText();
        if (a.equals(A) && b.equals(B) && c.equals(C) && d.equals(D) && e.equals(E)) {
            updatedlable.setText("No Update Available");
        } else {
            String querySQL = "UPDATE REGISTRATION SET EMAIL_ID= '" + B + "',CLNT_PASSWORD= '" + C + "',DATE_OF_BIRTH= '" + D + "',ACCOUNT_TYPE= '" + E + "' WHERE CLNT_NAME='" + a + "' ";

            try {
                dbConnection = getDBConnection();
                statement = dbConnection.createStatement();
                System.out.println(querySQL);
                statement.executeUpdate(querySQL);
                updatedlable.setText("Updated");

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @FXML
    private void loginbutton(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(tableViewScene);
        window.show();
    }

}
